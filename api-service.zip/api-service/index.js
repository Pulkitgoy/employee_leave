const express = require("express");
const { randomUUID } = require("node:crypto");

const app = express();
const port = Number(process.env.PORT) || 3000;

app.use(express.json());

// In-memory sample data. It resets whenever the server restarts.
const items = [];

let seed={
    "emp-101": { "name": "Asha", "daysLeft": 5 },
    "emp-102": { "name": "Ravi", "daysLeft": 1 }
}
let cnt=0 ;

app.post("/api/leave", (req, res) => {
    const name = typeof req.body //.name === "string" ? req.body.name.trim() : "";

    int curr_emp=seed.find(name.employeeId);
    if(curr_emp)
    {
        if(curr_emp.daysLeft>=name.days)
        {
            cnt=cnt+1;
            return {"leaveId":`lv-${cnt}`, "employeeId":curr_emp, "days":name.days, "status":"PENDING"};
        }
        else
            return {"leaveId":`lv-${cnt}`, "employeeId":curr_emp, "days":name.days, "status" : "DISCARD"}
    }
    else
    {
        return {"error":"400", "message":"No employee exist"};
    }
});

app.post("/api/leave/lv-1/approve",(req,res)=>{
    let name = req.body;
    if(curr_emp)
    {
        // if(curr_emp.daysLeft>=name.days)
        // {
            let daysleft = curr_emp.daysLeft-name.days;
            return {"leaveId":name.leaveId, "status":"APPROVED", "daysLeft":"daysleft"};
        // }
    }
    else
    {
        return "No employee Exist";
    }
})

app.listen(port, () => {
    console.log(`API server listening at http://localhost:${port}`);
});
